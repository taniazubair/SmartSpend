import { useState, useEffect, useMemo } from "react";
import axios from "axios";
import { motion, AnimatePresence } from "framer-motion";
import Sidebar from "../components/Sidebar";
import AddExpenseModal from "../components/AddExpenseModal";
import {
  FiPlus, FiSearch, FiCalendar, FiArrowUp, FiArrowDown,
  FiEdit2, FiTrash2, FiCoffee, FiShoppingBag, FiTruck,
  FiZap, FiFilm, FiHeart, FiBook, FiBox, FiInbox
} from "react-icons/fi";

const CATEGORIES = ["All", "Food", "Shopping", "Transport", "Bills", "Entertainment", "Health", "Education", "Other"];

const CATEGORY_ICONS = {
  Food: FiCoffee, Shopping: FiShoppingBag, Transport: FiTruck,
  Bills: FiZap, Entertainment: FiFilm, Health: FiHeart,
  Education: FiBook, Other: FiBox
};

const CATEGORY_COLORS = {
  Food: "text-orange-600 bg-orange-50 border-orange-100",
  Shopping: "text-pink-600 bg-pink-50 border-pink-100",
  Transport: "text-blue-600 bg-blue-50 border-blue-100",
  Bills: "text-yellow-600 bg-yellow-50 border-yellow-100",
  Entertainment: "text-purple-600 bg-purple-50 border-purple-100",
  Health: "text-red-600 bg-red-50 border-red-100",
  Education: "text-indigo-600 bg-indigo-50 border-indigo-100",
  Other: "text-gray-600 bg-gray-100 border-gray-200"
};

function CategoryIcon({ category }) {
  const Icon = CATEGORY_ICONS[category] || FiBox;
  const colorClass = CATEGORY_COLORS[category] || CATEGORY_COLORS.Other;
  return (
    <div className={`h-10 w-10 rounded-xl flex items-center justify-center shrink-0 ${colorClass}`}>
      <Icon className="w-5 h-5" />
    </div>
  );
}

const container = { hidden: { opacity: 0 }, show: { opacity: 1, transition: { staggerChildren: 0.08 } } };
const item = { hidden: { opacity: 0, y: 15 }, show: { opacity: 1, y: 0 } };

function Expenses() {
  const [expenses, setExpenses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingExpense, setEditingExpense] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [sortConfig, setSortConfig] = useState({ key: "date", direction: "desc" });
  const [deletingId, setDeletingId] = useState(null);

  const fetchExpenses = async () => {
    try {
      const res = await axios.get("http://localhost:5000/api/expenses", {
        headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
      });
      setExpenses(res.data.data || []);
    } catch (err) { console.log(err); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchExpenses(); }, []);

  const handleSaveExpense = async (expenseData) => {
    try {
      if (editingExpense) {
        await axios.put(`http://localhost:5000/api/expenses/${editingExpense._id}`, expenseData,
          { headers: { Authorization: `Bearer ${localStorage.getItem("token")}` } });
      } else {
        await axios.post("http://localhost:5000/api/expenses", expenseData,
          { headers: { Authorization: `Bearer ${localStorage.getItem("token")}` } });
      }
      setEditingExpense(null);
      fetchExpenses();
    } catch (err) { console.log(err); }
  };

  const openEditModal = (expense) => { setEditingExpense(expense); setIsModalOpen(true); };
  const openAddModal = () => { setEditingExpense(null); setIsModalOpen(true); };

  const handleDelete = async (id) => {
    setDeletingId(id);
    try {
      await axios.delete(`http://localhost:5000/api/expenses/${id}`, {
        headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
      });
      setExpenses((prev) => prev.filter((e) => e._id !== id));
    } catch (err) { console.log(err); }
    finally { setDeletingId(null); }
  };

  const filteredExpenses = useMemo(() => {
    let result = [...expenses];
    if (searchTerm) {
      result = result.filter((e) => 
        e.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        e.category.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }
    if (selectedCategory !== "All") result = result.filter((e) => e.category === selectedCategory);
    result.sort((a, b) => {
      if (sortConfig.key === "amount") return sortConfig.direction === "asc" ? a.amount - b.amount : b.amount - a.amount;
      return sortConfig.direction === "asc" ? new Date(a.date) - new Date(b.date) : new Date(b.date) - new Date(a.date);
    });
    return result;
  }, [expenses, searchTerm, selectedCategory, sortConfig]);

  const toggleSort = (key) => {
    setSortConfig((prev) => ({ 
      key, 
      direction: prev.key === key && prev.direction === "desc" ? "asc" : "desc" 
    }));
  };

  if (loading) {
    return (
      <div className="flex min-h-screen bg-gray-50">
        <Sidebar />
        <div className="flex-1 flex items-center justify-center">
          <motion.div animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 1, ease: "linear" }}
            className="w-12 h-12 border-4 border-blue-600 border-t-transparent rounded-full" />
        </div>
      </div>
    );
  }

  const hasData = expenses.length > 0;
  const hasFilteredData = filteredExpenses.length > 0;

  return (
    <div className="flex min-h-screen bg-gray-50 overflow-hidden">
      <Sidebar />

      <main className="flex-1 overflow-y-auto h-screen">
        <motion.div variants={container} initial="hidden" animate="show" className="px-6 py-8 max-w-7xl mx-auto">

          {/* Header */}
          <motion.div variants={item} className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">All Expenses</h1>
              <p className="text-gray-500 mt-1">Manage and track every transaction</p>
            </div>
            <motion.button whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}
              onClick={openAddModal}
              className="flex items-center gap-2 bg-gray-900 hover:bg-gray-800 text-white px-6 py-3 rounded-xl text-sm font-medium shadow-lg shadow-gray-200 transition-all shrink-0">
              <FiPlus /> Add Expense
            </motion.button>
          </motion.div>

          {hasData ? (
            <>
              {/* Search + Filters */}
              <motion.div variants={item} className="bg-white rounded-2xl shadow-sm border border-gray-200 p-4 mb-6">
                <div className="flex flex-col lg:flex-row gap-3">
                  <div className="flex items-center bg-gray-50 border border-gray-200 rounded-xl px-4 py-2.5 flex-1 focus-within:ring-2 focus-within:ring-blue-100 focus-within:border-blue-300 transition-all">
                    <FiSearch className="w-4 h-4 text-gray-400 mr-3" />
                    <input type="text" placeholder="Search transactions..." value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="bg-transparent border-none outline-none text-sm w-full" />
                  </div>
                  <div className="flex gap-2 overflow-x-auto pb-1 lg:pb-0 no-scrollbar">
                    {CATEGORIES.map((cat) => (
                      <button key={cat} onClick={() => setSelectedCategory(cat)}
                        className={`px-4 py-2 rounded-xl text-xs font-medium whitespace-nowrap transition-all ${
                          selectedCategory === cat 
                            ? "bg-gray-900 text-white shadow-md" 
                            : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                        }`}>
                        {cat}
                      </button>
                    ))}
                  </div>
                </div>
              </motion.div>

              {/* Table */}
              <motion.div variants={item} className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-gray-50/80">
                      <tr>
                        <th className="px-6 py-4 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Transaction</th>
                        <th className="px-6 py-4 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Category</th>
                        <th className="px-6 py-4 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider cursor-pointer hover:text-gray-700 select-none" onClick={() => toggleSort("date")}>
                          <span className="flex items-center gap-1">Date {sortConfig.key === "date" && (sortConfig.direction === "asc" ? <FiArrowUp className="w-3 h-3" /> : <FiArrowDown className="w-3 h-3" />)}</span>
                        </th>
                        <th className="px-6 py-4 text-right text-xs font-semibold text-gray-500 uppercase tracking-wider cursor-pointer hover:text-gray-700 select-none" onClick={() => toggleSort("amount")}>
                          <span className="flex items-center justify-end gap-1">Amount {sortConfig.key === "amount" && (sortConfig.direction === "asc" ? <FiArrowUp className="w-3 h-3" /> : <FiArrowDown className="w-3 h-3" />)}</span>
                        </th>
                        <th className="px-6 py-4 text-right text-xs font-semibold text-gray-500 uppercase tracking-wider w-24">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100">
                      <AnimatePresence mode="popLayout">
                        {hasFilteredData ? (
                          filteredExpenses.map((expense) => (
                            <motion.tr key={expense._id} layout initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0, scale: 0.95 }}
                              transition={{ type: "spring", stiffness: 300, damping: 30 }}
                              className="hover:bg-gray-50/80 transition-colors group">
                              <td className="px-6 py-4 whitespace-nowrap">
                                <div className="flex items-center gap-3">
                                  <CategoryIcon category={expense.category} />
                                  <div>
                                    <div className="text-sm font-semibold text-gray-900">{expense.title}</div>
                                    <div className="text-[11px] text-gray-400">#{expense._id.slice(-6)}</div>
                                  </div>
                                </div>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <span className="px-2.5 py-1 rounded-lg text-xs font-medium bg-gray-100 text-gray-700">{expense.category}</span>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                <span className="flex items-center gap-1.5"><FiCalendar className="w-3.5 h-3.5 text-gray-400" />{new Date(expense.date).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}</span>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-right">
                                <span className="text-sm font-bold text-gray-900">Rs. {Number(expense.amount).toLocaleString()}</span>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-right">
                                <div className="flex items-center justify-end gap-1 opacity-0 group-hover:opacity-100 transition-all">
                                  <motion.button whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }} onClick={() => openEditModal(expense)} className="p-2 rounded-lg hover:bg-gray-100 text-gray-400 hover:text-gray-700 transition-colors" title="Edit">
                                    <FiEdit2 className="w-4 h-4" />
                                  </motion.button>
                                  <motion.button whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }} onClick={() => handleDelete(expense._id)} disabled={deletingId === expense._id} className="p-2 rounded-lg hover:bg-red-50 text-gray-400 hover:text-red-600 transition-colors disabled:opacity-50" title="Delete">
                                    {deletingId === expense._id ? (
                                      <motion.div animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 1, ease: "linear" }} className="w-4 h-4 border-2 border-red-600 border-t-transparent rounded-full" />
                                    ) : (
                                      <FiTrash2 className="w-4 h-4" />
                                    )}
                                  </motion.button>
                                </div>
                              </td>
                            </motion.tr>
                          ))
                        ) : (
                          <tr>
                            <td colSpan="5" className="py-12 text-center">
                              <div className="w-14 h-14 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-3">
                                <FiSearch className="w-6 h-6 text-gray-400" />
                              </div>
                              <p className="text-base font-semibold text-gray-900">No matches found</p>
                              <p className="text-sm text-gray-500 mt-1">Try different search or filter</p>
                            </td>
                          </tr>
                        )}
                      </AnimatePresence>
                    </tbody>
                  </table>
                </div>

                {hasFilteredData && (
                  <div className="px-6 py-3 border-t border-gray-100 bg-gray-50/60">
                    <span className="text-xs text-gray-500">Showing {filteredExpenses.length} of {expenses.length} transactions</span>
                  </div>
                )}
              </motion.div>
            </>
          ) : (
            /* Empty State */
            <motion.div variants={item} className="bg-white rounded-2xl shadow-sm border border-gray-100 p-12 text-center">
              <div className="w-20 h-20 bg-blue-50 rounded-full flex items-center justify-center mx-auto mb-4">
                <FiInbox className="w-10 h-10 text-blue-500" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">No expenses yet</h3>
              <p className="text-gray-500 mb-6 max-w-md mx-auto">Start tracking your spending by adding your first expense.</p>
              <button onClick={openAddModal}
                className="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-xl font-medium transition-colors">
                <FiPlus /> Add Your First Expense
              </button>
            </motion.div>
          )}

        </motion.div>
      </main>

      <AddExpenseModal isOpen={isModalOpen} onClose={() => { setIsModalOpen(false); setEditingExpense(null); }}
        onSave={handleSaveExpense} initialData={editingExpense} />
    </div>
  );
}

export default Expenses;