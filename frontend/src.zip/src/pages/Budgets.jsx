import { useEffect, useState } from "react";
import { getBudgets, createBudget } from "../api/budgetApi";
import Sidebar from "../components/Sidebar";
import { AnimatePresence, motion } from "framer-motion";
import {
  FiPlus,
  FiDollarSign,
  FiTrendingUp,
  FiAlertCircle,
  FiX,
} from "react-icons/fi";

function Budgets() {
  const [budgets, setBudgets] = useState([]);
  const [showModal, setShowModal] = useState(false);

  const [formData, setFormData] = useState({
    category: "Food",
    limit: "",
    month: new Date().toISOString().slice(0, 7),
  });

  useEffect(() => {
    fetchBudgets();
  }, []);

  const fetchBudgets = async () => {
    try {
      const res = await getBudgets();
      console.log(res.data);
      setBudgets(res.data.data);
    } catch (err) {
      console.log(err);
    }
  };

 
  const handleCreateBudget = async () => {
  try {
    await createBudget({
      category: formData.category,
      limit: Number(formData.limit),
      month: formData.month,
    });

    fetchBudgets();

    setShowModal(false);

    setFormData({
      category: "Food",
      limit: "",
      month: new Date().toISOString().slice(0, 7),
    });

  } catch (error) {
    console.log(error);
    alert(
      error.response?.data?.message ||
      "Failed to create budget"
    );
  }
};

  return (
    <div className="flex min-h-screen bg-gray-100">
      <Sidebar />

      <div className="flex-1 p-8">

        {/* Header */}

        <div className="flex justify-between items-center mb-10">

          <div>
            <h1 className="text-4xl font-bold text-slate-800">
              Budget Planner
            </h1>

            <p className="text-gray-500 mt-2">
              Plan your monthly spending wisely.
            </p>
          </div>

          <button
            onClick={() => setShowModal(true)}
            className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-5 py-3 rounded-xl shadow-lg transition"
          >
            <FiPlus />
            Add Budget
          </button>

        </div>

        {/* Budget Cards */}

        <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-6">

          {budgets.length === 0 ? (

            <div className="col-span-full bg-white rounded-2xl p-10 text-center shadow">

              <h2 className="text-2xl font-bold mb-2">
                No Budgets Yet
              </h2>

              <p className="text-gray-500">
                Click "Add Budget" to create your first budget.
              </p>

            </div>

          ) : (

            budgets.map((budget) => {

              const spent = budget.spent || 0;

              const percentage =
                budget.limit > 0
                  ? (spent / budget.limit) * 100
                  : 0;

              return (

                <div
                  key={budget._id}
                  className="bg-white rounded-2xl shadow-lg p-6 hover:shadow-xl transition"
                >

                  <div className="flex justify-between items-center">

                    <div>

                      <h2 className="text-2xl font-bold">
                        {budget.category}
                      </h2>

                      <p className="text-gray-500">
                        {budget.month}
                      </p>

                    </div>

                    <FiDollarSign
                      className="text-blue-600"
                      size={32}
                    />

                  </div>

                  <div className="mt-6">

                    <div className="flex justify-between mb-2">

                      <span>Spent</span>

                      <span>
                        Rs. {spent.toLocaleString()}
                      </span>

                    </div>

                    <div className="w-full h-4 rounded-full bg-gray-200 overflow-hidden">

                      <div
                        className={`h-full rounded-full ${
                          percentage >= 100
                            ? "bg-red-500"
                            : percentage >= 80
                            ? "bg-yellow-500"
                            : "bg-green-500"
                        }`}
                        style={{
                          width: `${Math.min(percentage, 100)}%`,
                        }}
                      />

                    </div>

                    <div className="flex justify-between mt-3">

                      <span className="text-gray-500">
                        Limit
                      </span>

                      <span className="font-semibold">
                        Rs. {budget.limit.toLocaleString()}
                      </span>

                    </div>

                  </div>

                  <div className="mt-6">

                    {percentage >= 100 ? (

                      <div className="flex items-center gap-2 text-red-600 font-semibold">

                        <FiAlertCircle />

                        Budget Exceeded

                      </div>

                    ) : (

                      <div className="flex items-center gap-2 text-green-600 font-semibold">

                        <FiTrendingUp />

                        {Math.round(percentage)}% Used

                      </div>

                    )}

                  </div>

                </div>

              );

            })

          )}

        </div>

      </div>

      {/* Modal */}

      <AnimatePresence>

        {showModal && (

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/40 backdrop-blur-sm flex justify-center items-center z-50"
            onClick={() => setShowModal(false)}
          >

            <motion.div
              initial={{ scale: 0.8 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.8 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white rounded-3xl shadow-2xl p-8 w-full max-w-md"
            >

              <div className="flex justify-between items-center mb-6">

                <h2 className="text-2xl font-bold">
                  Create Budget
                </h2>

                <button onClick={() => setShowModal(false)}>
                  <FiX size={24} />
                </button>

              </div>

              <select
                className="w-full border p-3 rounded-xl mb-4"
                value={formData.category}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    category: e.target.value,
                  })
                }
              >
                <option>Food</option>
                <option>Shopping</option>
                <option>Transport</option>
                <option>Bills</option>
                <option>Entertainment</option>
                <option>Health</option>
                <option>Education</option>
                <option>Other</option>
              </select>

              <input
                type="number"
                placeholder="Budget Limit"
                className="w-full border p-3 rounded-xl mb-4"
                value={formData.limit}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    limit: e.target.value,
                  })
                }
              />

              <input
                type="month"
                className="w-full border p-3 rounded-xl mb-6"
                value={formData.month}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    month: e.target.value,
                  })
                }
              />

              <button
                onClick={handleCreateBudget}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-xl font-semibold"
              >
                Create Budget
              </button>

            </motion.div>

          </motion.div>

        )}

      </AnimatePresence>

    </div>
  );
}

export default Budgets;