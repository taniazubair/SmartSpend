import { useState } from "react";
import AddGoalModal from "../components/AddGoalModal";

function Goals() {
  const [isModalOpen, setIsModalOpen] = useState(false);

  const [goals, setGoals] = useState([
    {
      id: 1,
      title: "MacBook Pro",
      target: 300000,
      saved: 120000,
      deadline: "01 Jan 2027",
    },
  ]);

  const addGoal = (newGoal) => {
    setGoals((prev) => [...prev, newGoal]);
  };

  return (
    <>
      <div className="min-h-screen bg-slate-100 p-8">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-4xl font-bold">Goals</h1>

          <button
            onClick={() => setIsModalOpen(true)}
            className="bg-blue-600 text-white px-5 py-3 rounded-xl"
          >
            + Create Goal
          </button>
        </div>

        {goals.map((goal) => (
          <div
            key={goal.id}
            className="bg-white rounded-xl shadow p-6 mb-4"
          >
            <h2 className="text-2xl font-bold">{goal.title}</h2>

            <p>Target: Rs. {goal.target.toLocaleString()}</p>

            <p>Saved: Rs. {goal.saved.toLocaleString()}</p>

            <p>Deadline: {goal.deadline}</p>
          </div>
        ))}
      </div>

      <AddGoalModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onAddGoal={addGoal}
      />
    </>
  );
}

export default Goals;