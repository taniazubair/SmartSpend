import { useState, useEffect, useMemo } from "react";
import axios from "axios";
import { motion, AnimatePresence } from "framer-motion";

// Components
import Sidebar from "../components/Sidebar";
import AddExpenseModal from "../components/AddExpenseModal";

// Icons
import { 
  FiPlus, 
  FiDollarSign, 
  FiList, 
  FiTrendingUp, 
  FiPieChart,
  FiCalendar, 
  FiArrowUpRight, 
  FiArrowDownRight,
  FiActivity,
  FiChevronRight
} from "react-icons/fi";

// Charts
import { 
  PieChart, 
  Pie, 
  Cell, 
  ResponsiveContainer, 
  Tooltip,
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid
} from "recharts";

// ─── Constants ─────────────────────────────────────────────

const COLORS = [
  '#3B82F6', '#8B5CF6', '#EC4899', '#F59E0B', 
  '#10B981', '#6366F1', '#EF4444', '#14B8A6'
];

const WEEKLY_DATA = [
  { day: 'Mon', amount: 1200 },
  { day: 'Tue', amount: 800 },
  { day: 'Wed', amount: 2500 },
  { day: 'Thu', amount: 1800 },
  { day: 'Fri', amount: 3200 },
  { day: 'Sat', amount: 4500 },
  { day: 'Sun', amount: 900 },
];

// ─── Animation Variants ────────────────────────────────────

const containerVariants = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: { staggerChildren: 0.08 }
  }
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0 }
};

// ─── StatCard Component ────────────────────────────────────

function StatCard({ title, value, icon: Icon, color, trend }) {
  return (
    <motion.div 
      variants={itemVariants}
      className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100 
                 hover:shadow-md hover:-translate-y-0.5 transition-all duration-300"
    >
      <div className="flex items-center justify-between mb-3">
        <div className={`p-2.5 rounded-xl ${color} bg-opacity-10`}>
          <Icon className={`w-5 h-5 ${color.replace('bg-', 'text-')}`} />
        </div>
        {trend !== undefined && (
          <span className={`flex items-center gap-0.5 text-[10px] font-bold px-2 py-1 rounded-full ${
            trend > 0 ? 'bg-red-50 text-red-600' : 'bg-green-50 text-green-600'
          }`}>
            {trend > 0 ? <FiArrowUpRight className="w-3 h-3" /> : <FiArrowDownRight className="w-3 h-3" />}
            {Math.abs(trend)}%
          </span>
        )}
      </div>
      <p className="text-xs font-medium text-gray-500 uppercase tracking-wide mb-1">{title}</p>
      <h3 className="text-xl font-bold text-gray-900">{value}</h3>
    </motion.div>
  );
}

// ─── Main Dashboard Component ──────────────────────────────

function Dashboard() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [expenses, setExpenses] = useState([]);
  const [loading, setLoading] = useState(true);

  // Fetch expenses from backend — SAME as your original code
  const fetchExpenses = async () => {
    try {
      const res = await axios.get(
        "http://localhost:5000/api/expenses",
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        }
      );
      // FIX: Handle both res.data and res.data.data
      const data = res.data.data || res.data || [];
      setExpenses(Array.isArray(data) ? data : []);
    } catch (error) {
      console.error("Failed to fetch expenses:", error);
      setExpenses([]); // FIX: Set empty array on error
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchExpenses();
  }, []);

  // Calculate stats
  const totalExpenses = expenses.reduce((sum, e) => sum + Number(e.amount || 0), 0);
  const transactionCount = expenses.length;
  const highestExpense = expenses.length > 0 
    ? Math.max(...expenses.map(e => Number(e.amount || 0))) 
    : 0;
  const categoryCount = new Set(expenses.map(e => e.category).filter(Boolean)).size;

  // Recent 5 expenses
  const recentExpenses = useMemo(() => {
    return [...expenses]
      .sort((a, b) => new Date(b.date) - new Date(a.date))
      .slice(0, 5);
  }, [expenses]);

  // Category chart data — FIX: Safe check
  const chartData = useMemo(() => {
    if (!expenses.length) return [];
    const data = {};
    expenses.forEach(e => {
      if (e.category && e.amount) {
        data[e.category] = (data[e.category] || 0) + Number(e.amount);
      }
    });
    return Object.entries(data).map(([name, value]) => ({ name, value }));
  }, [expenses]);

  const hasData = expenses.length > 0;
  const hasChartData = chartData.length > 0;

  // Loading state
  if (loading) {
    return (
      <div className="flex min-h-screen bg-gray-50">
        <Sidebar />
        <div className="flex-1 flex items-center justify-center">
          <motion.div 
            animate={{ rotate: 360 }}
            transition={{ repeat: Infinity, duration: 1, ease: "linear" }}
            className="w-12 h-12 border-4 border-blue-600 border-t-transparent rounded-full"
          />
        </div>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen bg-gray-50 overflow-hidden">
      {/* Sidebar */}
      <Sidebar />

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto h-screen">
        <motion.div 
          variants={containerVariants}
          initial="hidden"
          animate="show"
          className="px-4 sm:px-6 lg:px-8 py-6 max-w-7xl mx-auto"
        >
          
          {/* ─── Header ───────────────────────────────────────── */}
          <motion.div 
            variants={itemVariants}
            className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6"
          >
            <div>
              <h1 className="text-2xl sm:text-3xl font-bold text-gray-900">
                Financial Overview
              </h1>
              <p className="text-gray-500 mt-1 text-sm">
                Welcome to SmartSpend 👋
              </p>
            </div>

            <motion.button
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.97 }}
              onClick={() => setIsModalOpen(true)}
              className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 
                         text-white px-5 py-2.5 rounded-xl text-sm font-medium 
                         shadow-lg shadow-blue-200 transition-colors shrink-0"
            >
              <FiPlus className="w-4 h-4" />
              Add Expense
            </motion.button>
          </motion.div>

          {/* ─── Stats Grid ───────────────────────────────────── */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            <StatCard 
              title="Total Expenses" 
              value={`Rs. ${totalExpenses.toLocaleString()}`}
              icon={FiDollarSign} 
              color="bg-red-500"
              trend={12}
            />
            <StatCard 
              title="Transactions" 
              value={transactionCount}
              icon={FiList} 
              color="bg-blue-500"
              trend={-5}
            />
            <StatCard 
              title="Highest" 
              value={hasData ? `Rs. ${highestExpense.toLocaleString()}` : "—"}
              icon={FiTrendingUp} 
              color="bg-purple-500"
            />
            <StatCard 
              title="Categories" 
              value={categoryCount || "—"}
              icon={FiPieChart} 
              color="bg-green-500"
            />
          </div>

          {/* ─── Content: Data or Empty State ─────────────────── */}
          {hasData ? (
            <>
              {/* Charts Row */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-6">
                
                {/* Weekly Bar Chart */}
                <motion.div 
                  variants={itemVariants}
                  className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100 lg:col-span-2"
                >
                  <h3 className="text-base font-bold text-gray-900 mb-0.5">
                    Weekly Overview
                  </h3>
                  <p className="text-xs text-gray-500 mb-4">
                    Your spending this week
                  </p>
                  <div className="h-56 w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={WEEKLY_DATA} barCategoryGap="20%">
                        <CartesianGrid 
                          strokeDasharray="3 3" 
                          vertical={false} 
                          stroke="#f3f4f6" 
                        />
                        <XAxis 
                          dataKey="day" 
                          axisLine={false} 
                          tickLine={false} 
                          tick={{ fill: '#9ca3af', fontSize: 12 }}
                          dy={5}
                        />
                        <YAxis 
                          axisLine={false} 
                          tickLine={false} 
                          tick={{ fill: '#9ca3af', fontSize: 11 }}
                          tickFormatter={(val) => val >= 1000 ? `${val/1000}k` : val}
                        />
                        <Tooltip 
                          cursor={{ fill: '#eff6ff', radius: 4 }}
                          formatter={(value) => [`Rs. ${value.toLocaleString()}`, 'Amount']}
                          contentStyle={{ 
                            borderRadius: '10px', 
                            border: 'none', 
                            boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)',
                            fontSize: '12px'
                          }}
                        />
                        <Bar 
                          dataKey="amount" 
                          fill="#3B82F6" 
                          radius={[6, 6, 0, 0]}
                          maxBarSize={50}
                        />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </motion.div>

                {/* Category Pie Chart */}
                <motion.div 
                  variants={itemVariants}
                  className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100"
                >
                  <h3 className="text-base font-bold text-gray-900 mb-0.5">
                    By Category
                  </h3>
                  <p className="text-xs text-gray-500 mb-4">
                    Where your money goes
                  </p>
                  <div className="h-48 w-full">
                    {hasChartData ? (
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={chartData}
                            cx="50%"
                            cy="50%"
                            innerRadius={40}
                            outerRadius={65}
                            paddingAngle={4}
                            dataKey="value"
                            stroke="none"
                          >
                            {chartData.map((entry, index) => (
                              <Cell 
                                key={`cell-${index}`} 
                                fill={COLORS[index % COLORS.length]} 
                              />
                            ))}
                          </Pie>
                          <Tooltip 
                            formatter={(value) => `Rs. ${Number(value).toLocaleString()}`}
                            contentStyle={{ 
                              borderRadius: '10px', 
                              border: 'none', 
                              boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)',
                              fontSize: '12px'
                            }}
                          />
                        </PieChart>
                      </ResponsiveContainer>
                    ) : (
                      <div className="h-full flex items-center justify-center text-gray-400 text-sm">
                        No category data
                      </div>
                    )}
                  </div>
                  
                  {/* Category Legend */}
                  {hasChartData && (
                    <div className="flex flex-wrap gap-2 mt-3 justify-center">
                      {chartData.map((entry, index) => (
                        <div key={entry.name} className="flex items-center gap-1">
                          <div 
                            className="w-2.5 h-2.5 rounded-full"
                            style={{ backgroundColor: COLORS[index % COLORS.length] }}
                          />
                          <span className="text-[10px] text-gray-600">{entry.name}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </motion.div>
              </div>

              {/* Recent Transactions */}
              <motion.div 
                variants={itemVariants}
                className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden"
              >
                <div className="p-5 border-b border-gray-100 flex justify-between items-center">
                  <div>
                    <h3 className="text-base font-bold text-gray-900">
                      Recent Transactions
                    </h3>
                    <p className="text-xs text-gray-500 mt-0.5">
                      Your latest expenses
                    </p>
                  </div>
                  <a 
                    href="/expenses" 
                    className="flex items-center gap-0.5 text-sm text-blue-600 
                               hover:text-blue-700 font-medium transition-colors"
                  >
                    View All 
                    <FiChevronRight className="w-4 h-4" />
                  </a>
                </div>

                <div className="divide-y divide-gray-100">
                  <AnimatePresence>
                    {recentExpenses.map((expense, index) => (
                      <motion.div 
                        key={expense._id}
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: index * 0.05 }}
                        className="flex items-center justify-between p-4 
                                   hover:bg-gray-50/80 transition-colors"
                      >
                        <div className="flex items-center gap-3">
                          <div className="h-10 w-10 rounded-xl bg-gradient-to-br 
                                          from-blue-50 to-indigo-50 flex items-center 
                                          justify-center text-blue-600 font-bold text-sm
                                          border border-blue-100">
                            {expense.title.charAt(0).toUpperCase()}
                          </div>
                          <div>
                            <div className="text-sm font-medium text-gray-900">
                              {expense.title}
                            </div>
                            <div className="text-xs text-gray-500 flex items-center gap-1">
                              <FiCalendar className="w-3 h-3" />
                              {new Date(expense.date).toLocaleDateString('en-US', {
                                month: 'short',
                                day: 'numeric',
                                year: 'numeric'
                              })}
                            </div>
                          </div>
                        </div>
                        <span className="text-sm font-bold text-red-500">
                          Rs. {Number(expense.amount).toLocaleString()}
                        </span>
                      </motion.div>
                    ))}
                  </AnimatePresence>
                </div>
              </motion.div>
            </>
          ) : (
            /* ─── Empty State ────────────────────────────────── */
            <motion.div 
              variants={itemVariants}
              className="bg-white rounded-2xl shadow-sm border border-gray-100 
                         p-12 text-center"
            >
              <motion.div 
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: "spring", stiffness: 200, damping: 15 }}
                className="w-20 h-20 bg-blue-50 rounded-full flex items-center 
                           justify-center mx-auto mb-4"
              >
                <FiActivity className="w-10 h-10 text-blue-500" />
              </motion.div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">
                No expenses yet
              </h3>
              <p className="text-gray-500 mb-6 max-w-md mx-auto text-sm">
                Start tracking your spending by adding your first expense. 
                It only takes a few seconds!
              </p>
              <motion.button
                whileHover={{ scale: 1.03 }}
                whileTap={{ scale: 0.97 }}
                onClick={() => setIsModalOpen(true)}
                className="inline-flex items-center gap-2 bg-blue-600 
                           hover:bg-blue-700 text-white px-6 py-3 rounded-xl 
                           font-medium transition-colors shadow-lg shadow-blue-200"
              >
                <FiPlus className="w-4 h-4" />
                Add Your First Expense
              </motion.button>
            </motion.div>
          )}

        </motion.div>
      </main>

      {/* Add Expense Modal — SAME props as your original */}
      <AddExpenseModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onExpenseAdded={fetchExpenses}
      />
    </div>
  );
}

export default Dashboard;