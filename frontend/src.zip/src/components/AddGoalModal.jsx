import { useState } from "react";

function AddGoalModal({ isOpen, onClose, onAddGoal }) {
  const [goal, setGoal] = useState({
    title: "",
    target: "",
    deadline: "",
  });

  if (!isOpen) return null;

  const handleChange = (e) => {
    setGoal({
      ...goal,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    const newGoal = {
      id: Date.now(),
      title: goal.title,
      target: Number(goal.target),
      saved: 0,
      deadline: goal.deadline,
    };

    onAddGoal(newGoal);

    alert("Goal Created Successfully!");

    setGoal({
      title: "",
      target: "",
      deadline: "",
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-white rounded-3xl p-8 w-full max-w-lg">
        <h2 className="text-3xl font-bold mb-6">
          Create Goal
        </h2>

        <form onSubmit={handleSubmit} className="space-y-5">
          <input
            type="text"
            name="title"
            placeholder="Goal Name"
            value={goal.title}
            onChange={handleChange}
            className="w-full border rounded-xl p-3"
            required
          />

          <input
            type="number"
            name="target"
            placeholder="Target Amount"
            value={goal.target}
            onChange={handleChange}
            className="w-full border rounded-xl p-3"
            required
          />

          <input
            type="date"
            name="deadline"
            value={goal.deadline}
            onChange={handleChange}
            className="w-full border rounded-xl p-3"
            required
          />

          <div className="flex justify-end gap-4">
            <button
              type="button"
              onClick={onClose}
              className="bg-gray-200 px-5 py-3 rounded-xl"
            >
              Cancel
            </button>

            <button
              type="submit"
              className="bg-blue-600 text-white px-6 py-3 rounded-xl hover:bg-blue-700"
            >
              Create Goal
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default AddGoalModal;