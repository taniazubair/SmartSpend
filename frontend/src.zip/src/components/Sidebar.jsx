import { useNavigate } from "react-router-dom";
import {
  FiHome,
  FiDollarSign,
  FiPieChart,
  FiTarget,
  FiLogOut,
} from "react-icons/fi";

function Sidebar() {
  const navigate = useNavigate();

  const menu = [
    { name: "Dashboard", icon: FiHome, path: "/dashboard" },
    { name: "Expenses", icon: FiDollarSign, path: "/expenses" },
    { name: "Budgets", icon: FiPieChart, path: "/budgets" },
    { name: "Goals", icon: FiTarget, path: "/goals" },
  ];

  const handleLogout = () => {
    localStorage.removeItem("token");
    navigate("/login");
  };

  return (
    <aside className="w-72 min-h-screen bg-slate-900 text-white flex flex-col shadow-xl">
      
      {/* Logo */}
      <div className="p-8 border-b border-slate-800">
        <h1 className="text-3xl font-bold text-blue-400">
          SmartSpend
        </h1>

        <p className="text-slate-400 mt-2">
          Personal Finance Tracker
        </p>
      </div>

      {/* Menu */}
      <nav className="flex-1 p-4">
        {menu.map((item) => {
          const Icon = item.icon;

          return (
            <button
              key={item.name}
              onClick={() => navigate(item.path)}
              className="w-full flex items-center gap-4 p-4 mb-3 rounded-xl hover:bg-slate-800 transition text-left"
            >
              <Icon size={20} />
              <span>{item.name}</span>
            </button>
          );
        })}
      </nav>

      {/* Logout */}
      <div className="p-4 border-t border-slate-800">
        <button
          onClick={handleLogout}
          className="w-full flex items-center justify-center gap-2 bg-red-500 hover:bg-red-600 p-3 rounded-xl transition"
        >
          <FiLogOut />
          Logout
        </button>
      </div>
    </aside>
  );
}

export default Sidebar;